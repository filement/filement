// Filement32.cpp : main project file.

#include "stdafx.h"
#include "Form1.h"
#include "LimitSingleInstance.h"

CLimitSingleInstance g_SingleInstanceObj(TEXT("Global\\{6ADE6C34-0D7B-4435-9614-60D3295EECE8}"));

using namespace Filement32;

[STAThreadAttribute]
int main(array<System::String ^> ^args)
{
	if(args->Length > 0 && !String::Compare(args[0],"reinit"))
	{
		String^ db = System::IO::Path::Combine( Environment::GetFolderPath( Environment::SpecialFolder::LocalApplicationData ), "Filement" );
		String^ file = System::IO::Path::Combine(db, "Filement.db");
		try
		{
		System::IO::File::Delete(file);
		}
		catch (int e)
                {
                    MessageBox::Show("Can't delete the database file.");
                }
	}

	if (g_SingleInstanceObj.IsAnotherInstanceRunning())
       return FALSE; 

	// Enabling Windows XP visual effects before any controls are created
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false); 

	// Create the main window and run it
	Application::Run(gcnew Form1());
	return 0;
}
