The FFmpeg static build for win 32.

Source Code URL: https://ffmpeg.org/

ffmpeg info:

ffmpeg version N-52143-g2d8a3cf Copyright (c) 2000-2013 the FFmpeg developers
  built on Apr 16 2013 16:34:21 with gcc 4.8.0 (GCC)
  configuration: --enable-static --arch=x86 --target-os=mingw32 --cross-prefix=/ffmpeg_build/build/mgw/mingw-w64-i686/bin/i686-w64-mingw32- --pkg-config=pkg-config --enable-gpl --disable-ffplay --disable-ffprobe --enable-libx264 --enable-avisynth --enable-libmp3lame --enable-libvorbis --enable-libtheora --enable-libspeex --enable-libfreetype --enable-fontconfig --enable-libass --disable-w32threads --enable-filter=subtitles --extra-cflags=-DPTW32_STATIC_LIB --enable-libvpx --enable-runtime-cpudetect
  libavutil      52. 26.100 / 52. 26.100
  libavcodec     55.  2.100 / 55.  2.100
  libavformat    55.  2.100 / 55.  2.100
  libavdevice    55.  0.100 / 55.  0.100
  libavfilter     3. 56.101 /  3. 56.101
  libswscale      2.  2.100 /  2.  2.100
  libswresample   0. 17.102 /  0. 17.102
  libpostproc    52.  3.100 / 52.  3.100
Hyper fast Audio and Video encoder

Licenses for each library can be found in the licenses folder.

URLs of the external libraries:
libiconv - http://gnu.org/software/libiconv/
libass - http://code.google.com/p/libass/
FreeType - http://freetype.sourceforge.net/
LAME - http://lame.sourceforge.net/
OpenCORE - http://sourceforge.net/projects/opencore-amr/
Speex - http://speex.org/
Theora - http://theora.org/
Vorbis - http://vorbis.com/
vpx (webm) - http://webmproject.org/
x264 - http://videolan.org/developers/x264.html
zlib - http://zlib.net/



