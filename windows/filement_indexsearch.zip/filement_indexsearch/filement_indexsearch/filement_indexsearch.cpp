// filement_indexsearch.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
using namespace std;

struct vector * WindowsSearchQuery(WCHAR *pszSQL);
int xwcstoutf(char *utf, const wchar_t *wcs, size_t utflen);
extern "C" __declspec(dllexport) struct vector * __cdecl search_index_results(wchar_t *path,wchar_t *name);
extern "C" __declspec(dllexport) void __cdecl search_index_free(struct vector *vec_res);

struct search_entry
{
	char *path;
	struct _stat64 info;
};

struct vector
{
	void **data;
	size_t length, size;
};

#define VECTOR_SIZE_BASE 4

#define vector_length(vector) ((vector)->length) /* TODO: DEPRECATED. use vector->length instead */
bool vector_init(struct vector *v, size_t size);
#define vector_get(vector, index) ((vector)->data[index])
bool vector_add(struct vector *v, void *value);
#define vector_term(vector) (free((vector)->data))


bool vector_init(struct vector *v, size_t size)
{
	v->length = 0;
	v->size = size;

	v->data =(void **)malloc(sizeof(void *) * size);
	if (!v->data) return 0;
	return !!v;
}

bool vector_add(struct vector *v, void *value)
{
	if (v->length == v->size)
	{
		v->size *= 2;
		v->data =(void **) realloc(v->data, sizeof(void *) * v->size);
		if (!v->data) return 0;
	}
	return !!(v->data[v->length++] = value);
}

int xwcstoutf(char *utf, const wchar_t *wcs, size_t utflen)
{
if (!wcs || !utf || utflen < 1) {
errno = EINVAL;
return -1;
}
utflen = WideCharToMultiByte(CP_UTF8, 0, wcs, -1, utf, utflen, NULL, NULL);
if (utflen)
return utflen - 1;
errno = ERANGE;
return -1;
}

__declspec(dllexport) struct vector * __cdecl search_index_results(wchar_t *path,wchar_t *name)
{
	 
	wchar_t *query=0;
	unsigned int path_len=lstrlen(path);
	if(path_len<3)return 0;
	
	query=(wchar_t *)malloc(sizeof(wchar_t)*(sizeof(L"SELECT \"Path\", \"System.Size\", \"System.ItemType\" FROM \"SystemIndex\" WHERE ( (\"Path\" LIKE 'file:%') AND (\"System.ItemNameDisplay\" LIKE '%%'))")+path_len+lstrlen(name)+sizeof(L'\0')));
	wsprintf(query,L"SELECT \"Path\", \"System.Size\", \"System.ItemType\" FROM \"SystemIndex\" WHERE ( (\"Path\" LIKE 'file:%s%%') AND (\"System.ItemNameDisplay\" LIKE '%%%s%%'))",path,name);
HRESULT hr = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
    if (SUCCEEDED(hr)) 
    {
		//WindowsSearchQuery(L"SELECT \"System.ItemPathDisplay\" FROM \"SystemIndex\" WHERE ( (\"System.ItemPathDisplay\" LIKE 'C:\\Users\\Nikola\\Documents\\new folder\\%') AND (\"System.ItemNameDisplay\" LIKE '%mp3%') ) ");
		return WindowsSearchQuery(query);
	
	}

return 0;
}

__declspec(dllexport) void __cdecl search_index_free(struct vector *vec_res)
{
	unsigned int i=0;
 	for(i=0;i<vec_res->length;i++)
	{
		free(vec_res->data[i]);
	}
	vector_term(vec_res);
	free(vec_res);
}


struct vector * WindowsSearchQuery(WCHAR *pszSQL)
{
	HRESULT hr;
	struct vector *vec_res=0;
	struct search_entry *search_entry=0;
	char *tmp=0;
	int i=0;
	char buffer[2048];//To check is it enought
	vec_res=(struct vector *)malloc(sizeof(struct vector ));
	vector_init(vec_res,32);
        // use ATL OLEDB classes to connect to the database and get the results
        CDataSource cDataSource;

        hr = cDataSource.OpenFromInitializationString(L"provider=Search.CollatorDSO.1;EXTENDED PROPERTIES=\"Application=Windows\"");
        if (SUCCEEDED(hr))
        {
            CSession cSession;

            hr = cSession.Open(cDataSource);
            if (SUCCEEDED(hr))
            {
                CCommand<CDynamicAccessor, CRowset> cCommand;

                hr = cCommand.Open(cSession, pszSQL);
                if (SUCCEEDED(hr))
                {
                    for (hr = cCommand.MoveFirst(); S_OK == hr; hr = cCommand.MoveNext())
                    {
                            DBSTATUS status;
                            cCommand.GetStatus(1, &status);
                            if (status == DBSTATUS_S_OK || status == DBSTATUS_S_TRUNCATED)
                            {

								 DBTYPE type;
                                cCommand.GetColumnType(1, &type);
                                switch (type) 
                                {
                                case DBTYPE_VARIANT:
                                {
                                    VARIANT *pVar = (VARIANT *)cCommand.GetValue(1);

                                    if (pVar->vt == VT_BSTR) 
                                    {
										buffer[0]=0;
										xwcstoutf(buffer, (wchar_t *)pVar->bstrVal, 2047);
										tmp=_strdup(buffer+5);
										if(!tmp)continue;
										tmp[1]=tmp[0];
										tmp[0]='/';
										search_entry=(struct search_entry *)malloc(sizeof(struct search_entry));
										search_entry->path=tmp;
										vector_add(vec_res,search_entry);
                                       
                                    } 
                                   
                                }
                                break;

                                case DBTYPE_WSTR:
										buffer[0]=0;
										xwcstoutf(buffer, (wchar_t *)cCommand.GetValue(1), 2047);
										tmp=_strdup(buffer+5);
										if(!tmp)continue;
										tmp[1]=tmp[0];
										tmp[0]='/';
										search_entry=(struct search_entry *)malloc(sizeof(struct search_entry));
										search_entry->path=tmp;
										vector_add(vec_res,search_entry);
                                    break;             

                                default:
                                    break;
                                }


							   
                            } 
                            else 
                            {
								vector_term(vec_res);
                                return 0;
                            }

							cCommand.GetStatus(2, &status);
                            if (status == DBSTATUS_S_OK || status == DBSTATUS_S_TRUNCATED)
                            {
								search_entry->info.st_size=*(LONGLONG *)cCommand.GetValue(2);
							}
							else
							{
								search_entry->info.st_size=0;
							}

							search_entry->info.st_mode=0;

							cCommand.GetStatus(3, &status);
                            if (status == DBSTATUS_S_OK || status == DBSTATUS_S_TRUNCATED)
                            {
								 DBTYPE type;
                                cCommand.GetColumnType(3, &type);
                                if (type==DBTYPE_VARIANT) 
                                {
                                
                                    VARIANT *pVar = (VARIANT *)cCommand.GetValue(3);

                                    if (pVar->vt == VT_BSTR)
                                    {
										if(!wcscmp((wchar_t *)pVar->bstrVal,L"Folder") || !wcscmp((wchar_t *)pVar->bstrVal,L"Directory"))search_entry->info.st_mode |= S_IFDIR;
										else search_entry->info.st_mode |= S_IFREG;
                                    }
								}
								

									
							}
							

							//TODO Date and time 
								search_entry->info.st_mtime=0;
								search_entry->info.st_ctime=0;
								search_entry->info.st_atime=0;
							
								search_entry->info.st_ino=0;
								search_entry->info.st_dev=0;
								
                        

                    }

                    if (DB_S_ENDOFROWSET == hr)
                    {
                        hr = S_FALSE;   // no rows
                    } 
                    else 
                    {
						vector_term(vec_res);
                        return 0;
                    }

                    // else it's S_OK or an error message
                    cCommand.Close();
                } 
                else 
                {
                   vector_term(vec_res);
                        return 0;
                }
                cCommand.ReleaseCommand();
            }
        }
        free(pszSQL);
    
    return vec_res;
}

