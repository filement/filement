// filement_upgrade.cpp : main project file.

#include "stdafx.h"
#include "Form1.h"
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <vcclr.h>

using namespace filement_upgrade;

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Runtime::InteropServices;
	using namespace System::Reflection;
	using namespace System::Threading;
	using namespace Microsoft::Win32;

[STAThreadAttribute]
int main(array<System::String ^> ^args)
{
	// Enabling Windows XP visual effects before any controls are created
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false); 
	
	if(args->Length )
	{
		pin_ptr<const wchar_t> loc_conv=PtrToStringChars(args[0]);

		Application::Run(gcnew Form1((wchar_t *)loc_conv));
	}
	else Application::Run(gcnew Form1(0));
	return 0;
}
