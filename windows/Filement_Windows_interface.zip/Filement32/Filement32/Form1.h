#pragma once
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <vcclr.h>

/*
#define _AFXDLL
#include <afx.h>
#include <afxwin.h>


#include <shellapi.h>
#define WM_MYMESSAGE (WM_USER + 1)
*/

namespace Filement32 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Runtime::InteropServices;
	using namespace System::Reflection;
	using namespace System::Threading;
	using namespace Microsoft::Win32;

	
		[DllImport("filement_device_lib.dll", CallingConvention=CallingConvention::Cdecl)]
        int filement_export_check_device(wchar_t *_loc);

        [DllImport("filement_device_lib.dll", CallingConvention=CallingConvention::Cdecl)]
        int filement_export_register_device(wchar_t *_loc, wchar_t *_email, wchar_t *_pin, wchar_t *_pass, wchar_t *_dev_name);

        [DllImport("filement_device_lib.dll", CallingConvention=CallingConvention::Cdecl)]
        int filement_export_start_server(wchar_t *_loc);

        [DllImport("filement_device_lib.dll",CallingConvention=CallingConvention::Cdecl)]
       void filement_export_exit();

        [DllImport("filement_device_lib.dll", CallingConvention=CallingConvention::Cdecl)]
        wchar_t * filement_export_get_version();

        [DllImport("filement_device_lib.dll", CallingConvention=CallingConvention::Cdecl)]
        void filement_export_exec_reinit(wchar_t * _loc);		

	
	static wchar_t *GetAssemblyPath()
	{
	pin_ptr<const wchar_t> unmngStr = PtrToStringChars(Assembly::GetExecutingAssembly()->Location);
	return (wchar_t *)unmngStr;
	}

	static void RegisterInStartup(bool isChecked)
        {
			RegistryKey ^ rkCurrentUser = Registry::CurrentUser;
			RegistryKey ^ registryKey = rkCurrentUser->OpenSubKey( L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run",true );
            if(registryKey)
			{
			if (isChecked)
            {
                registryKey->SetValue(L"Filement", Application::ExecutablePath);
            }
            else
            {
                registryKey->DeleteValue(L"Filement");
            }
			 registryKey->Close();
			}

			if (rkCurrentUser)rkCurrentUser->Close();
        }

	static void Server_Start()
        {
            wchar_t *loc=GetAssemblyPath();
            if (filement_export_start_server(loc) == 0)
            {
                MessageBox::Show("Problems with starting the server.");
              //TODO: error
            }    
           
        }


	/// <summary>
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:

		Thread^ filement_thread;
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//

			wchar_t *loc=GetAssemblyPath();
			 if (filement_export_check_device(loc) == 1)
            {
				filement_thread = gcnew Thread(gcnew ThreadStart(Server_Start));
				filement_thread->Name="Filement Server";
				filement_thread->Start();
               
				this->Visible = false;
                this->ShowInTaskbar = false;
				this->WindowState= FormWindowState::Minimized;
            }
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			this->TrayIcon->Visible = false;
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::NotifyIcon^  TrayIcon;
	protected: 
	private: System::Windows::Forms::ContextMenuStrip^  TrayMenu;
	private: System::Windows::Forms::ToolStripMenuItem^  ctx_add_new_device;
	private: System::Windows::Forms::ToolStripMenuItem^  ctx_stop_server;
	private: System::Windows::Forms::ToolStripMenuItem^  aboutToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  AboutVersion;
	private: System::Windows::Forms::ToolStripMenuItem^  filementcomToolStripMenuItem;
	private: System::Windows::Forms::PictureBox^  Close;
	private: System::Windows::Forms::PictureBox^  PairButton;
	private: System::Windows::Forms::TextBox^  dname_box;
	private: System::Windows::Forms::TextBox^  email_box;

	private: System::Windows::Forms::TextBox^  PasswordBox;
	private: System::Windows::Forms::PictureBox^  ShowPasswordBox;
	private: System::Windows::Forms::PictureBox^  hidePassword;

	private: System::Windows::Forms::PictureBox^  pass_descr_image;
	private: System::Windows::Forms::PictureBox^  PinHintBox;
	private: System::ComponentModel::IContainer^  components;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->TrayIcon = (gcnew System::Windows::Forms::NotifyIcon(this->components));
			this->TrayMenu = (gcnew System::Windows::Forms::ContextMenuStrip(this->components));
			this->ctx_add_new_device = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->ctx_stop_server = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->aboutToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->AboutVersion = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->filementcomToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->Close = (gcnew System::Windows::Forms::PictureBox());
			this->PairButton = (gcnew System::Windows::Forms::PictureBox());
			this->dname_box = (gcnew System::Windows::Forms::TextBox());
			this->email_box = (gcnew System::Windows::Forms::TextBox());
			this->PasswordBox = (gcnew System::Windows::Forms::TextBox());
			this->ShowPasswordBox = (gcnew System::Windows::Forms::PictureBox());
			this->hidePassword = (gcnew System::Windows::Forms::PictureBox());
			this->pass_descr_image = (gcnew System::Windows::Forms::PictureBox());
			this->PinHintBox = (gcnew System::Windows::Forms::PictureBox());
			this->TrayMenu->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Close))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->PairButton))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->ShowPasswordBox))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->hidePassword))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pass_descr_image))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->PinHintBox))->BeginInit();
			this->SuspendLayout();
			// 
			// TrayIcon
			// 
			this->TrayIcon->ContextMenuStrip = this->TrayMenu;
			this->TrayIcon->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"TrayIcon.Icon")));
			this->TrayIcon->Text = L"Filement";
			this->TrayIcon->Visible = true;
			// 
			// TrayMenu
			// 
			this->TrayMenu->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->ctx_add_new_device, 
				this->ctx_stop_server, this->aboutToolStripMenuItem});
			this->TrayMenu->Name = L"TrayMenu";
			this->TrayMenu->Size = System::Drawing::Size(143, 70);
			// 
			// ctx_add_new_device
			// 
			this->ctx_add_new_device->Name = L"ctx_add_new_device";
			this->ctx_add_new_device->Size = System::Drawing::Size(142, 22);
			this->ctx_add_new_device->Text = L"Reinit Device";
			this->ctx_add_new_device->Click += gcnew System::EventHandler(this, &Form1::ctx_add_new_device_Click);
			// 
			// ctx_stop_server
			// 
			this->ctx_stop_server->Name = L"ctx_stop_server";
			this->ctx_stop_server->Size = System::Drawing::Size(142, 22);
			this->ctx_stop_server->Text = L"Stop Server";
			this->ctx_stop_server->Click += gcnew System::EventHandler(this, &Form1::ctx_stop_server_Click);
			// 
			// aboutToolStripMenuItem
			// 
			this->aboutToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->AboutVersion, 
				this->filementcomToolStripMenuItem});
			this->aboutToolStripMenuItem->Name = L"aboutToolStripMenuItem";
			this->aboutToolStripMenuItem->Size = System::Drawing::Size(142, 22);
			this->aboutToolStripMenuItem->Text = L"About";
			// 
			// AboutVersion
			// 
			this->AboutVersion->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->AboutVersion->Name = L"AboutVersion";
			this->AboutVersion->ShowShortcutKeys = false;
			this->AboutVersion->Size = System::Drawing::Size(147, 22);
			this->AboutVersion->Text = L"Version: 0.9.0";
			// 
			// filementcomToolStripMenuItem
			// 
			this->filementcomToolStripMenuItem->ForeColor = System::Drawing::Color::DodgerBlue;
			this->filementcomToolStripMenuItem->Name = L"filementcomToolStripMenuItem";
			this->filementcomToolStripMenuItem->Size = System::Drawing::Size(147, 22);
			this->filementcomToolStripMenuItem->Text = L"Filement.com";
			this->filementcomToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::filementcomToolStripMenuItem_Click);
			// 
			// Close
			// 
			this->Close->BackColor = System::Drawing::Color::Transparent;
			this->Close->Cursor = System::Windows::Forms::Cursors::Hand;
			this->Close->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"Close.Image")));
			this->Close->ImeMode = System::Windows::Forms::ImeMode::NoControl;
			this->Close->Location = System::Drawing::Point(606, 12);
			this->Close->Name = L"Close";
			this->Close->Size = System::Drawing::Size(22, 22);
			this->Close->TabIndex = 1;
			this->Close->TabStop = false;
			this->Close->Click += gcnew System::EventHandler(this, &Form1::Close_Click);
			// 
			// PairButton
			// 
			this->PairButton->BackColor = System::Drawing::Color::Transparent;
			this->PairButton->Cursor = System::Windows::Forms::Cursors::Hand;
			this->PairButton->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"PairButton.Image")));
			this->PairButton->ImeMode = System::Windows::Forms::ImeMode::NoControl;
			this->PairButton->InitialImage = nullptr;
			this->PairButton->Location = System::Drawing::Point(474, 302);
			this->PairButton->Name = L"PairButton";
			this->PairButton->Size = System::Drawing::Size(124, 36);
			this->PairButton->TabIndex = 13;
			this->PairButton->TabStop = false;
			this->PairButton->Click += gcnew System::EventHandler(this, &Form1::PairButton_Click);
			// 
			// dname_box
			// 
			this->dname_box->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->dname_box->Font = (gcnew System::Drawing::Font(L"Segoe UI", 10));
			this->dname_box->Location = System::Drawing::Point(357, 132);
			this->dname_box->Name = L"dname_box";
			this->dname_box->Size = System::Drawing::Size(230, 18);
			this->dname_box->TabIndex = 14;
			// 
			// email_box
			// 
			this->email_box->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->email_box->Font = (gcnew System::Drawing::Font(L"Segoe UI", 10));
			this->email_box->Location = System::Drawing::Point(357, 195);
			this->email_box->Name = L"email_box";
			this->email_box->Size = System::Drawing::Size(230, 18);
			this->email_box->TabIndex = 15;
			this->email_box->Leave += gcnew System::EventHandler(this, &Form1::email_box_Leave);
			this->email_box->Enter += gcnew System::EventHandler(this, &Form1::email_box_Enter);
			// 
			// PasswordBox
			// 
			this->PasswordBox->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->PasswordBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 10));
			this->PasswordBox->Location = System::Drawing::Point(356, 258);
			this->PasswordBox->Name = L"PasswordBox";
			this->PasswordBox->Size = System::Drawing::Size(209, 18);
			this->PasswordBox->TabIndex = 17;
			this->PasswordBox->UseSystemPasswordChar = true;
			this->PasswordBox->Leave += gcnew System::EventHandler(this, &Form1::PasswordBox_Leave);
			this->PasswordBox->Enter += gcnew System::EventHandler(this, &Form1::PasswordBox_Enter);
			// 
			// ShowPasswordBox
			// 
			this->ShowPasswordBox->BackColor = System::Drawing::Color::Transparent;
			this->ShowPasswordBox->Cursor = System::Windows::Forms::Cursors::Hand;
			this->ShowPasswordBox->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"ShowPasswordBox.Image")));
			this->ShowPasswordBox->ImeMode = System::Windows::Forms::ImeMode::NoControl;
			this->ShowPasswordBox->Location = System::Drawing::Point(570, 256);
			this->ShowPasswordBox->Name = L"ShowPasswordBox";
			this->ShowPasswordBox->Size = System::Drawing::Size(22, 22);
			this->ShowPasswordBox->TabIndex = 18;
			this->ShowPasswordBox->TabStop = false;
			this->ShowPasswordBox->Click += gcnew System::EventHandler(this, &Form1::ShowPasswordBox_Click);
			// 
			// hidePassword
			// 
			this->hidePassword->BackColor = System::Drawing::Color::Transparent;
			this->hidePassword->Cursor = System::Windows::Forms::Cursors::Hand;
			this->hidePassword->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"hidePassword.Image")));
			this->hidePassword->ImeMode = System::Windows::Forms::ImeMode::NoControl;
			this->hidePassword->Location = System::Drawing::Point(570, 256);
			this->hidePassword->Name = L"hidePassword";
			this->hidePassword->Size = System::Drawing::Size(22, 22);
			this->hidePassword->TabIndex = 19;
			this->hidePassword->TabStop = false;
			this->hidePassword->Visible = false;
			this->hidePassword->Click += gcnew System::EventHandler(this, &Form1::hidePassword_Click);
			// 
			// pass_descr_image
			// 
			this->pass_descr_image->BackColor = System::Drawing::Color::Transparent;
			this->pass_descr_image->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pass_descr_image.Image")));
			this->pass_descr_image->ImeMode = System::Windows::Forms::ImeMode::NoControl;
			this->pass_descr_image->Location = System::Drawing::Point(209, 302);
			this->pass_descr_image->Name = L"pass_descr_image";
			this->pass_descr_image->Size = System::Drawing::Size(253, 50);
			this->pass_descr_image->TabIndex = 21;
			this->pass_descr_image->TabStop = false;
			this->pass_descr_image->Visible = false;
			// 
			// PinHintBox
			// 
			this->PinHintBox->BackColor = System::Drawing::Color::Transparent;
			this->PinHintBox->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"PinHintBox.Image")));
			this->PinHintBox->ImeMode = System::Windows::Forms::ImeMode::NoControl;
			this->PinHintBox->Location = System::Drawing::Point(209, 302);
			this->PinHintBox->Name = L"PinHintBox";
			this->PinHintBox->Size = System::Drawing::Size(253, 75);
			this->PinHintBox->TabIndex = 22;
			this->PinHintBox->TabStop = false;
			this->PinHintBox->Visible = false;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(640, 400);
			this->Controls->Add(this->PinHintBox);
			this->Controls->Add(this->pass_descr_image);
			this->Controls->Add(this->hidePassword);
			this->Controls->Add(this->ShowPasswordBox);
			this->Controls->Add(this->PairButton);
			this->Controls->Add(this->email_box);
			this->Controls->Add(this->PasswordBox);
			this->Controls->Add(this->dname_box);
			this->Controls->Add(this->Close);
			this->Font = (gcnew System::Drawing::Font(L"Segoe UI", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->MaximizeBox = false;
			this->MaximumSize = System::Drawing::Size(640, 400);
			this->MinimumSize = System::Drawing::Size(640, 400);
			this->Name = L"Form1";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Filement";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->TrayMenu->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Close))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->PairButton))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->ShowPasswordBox))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->hidePassword))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pass_descr_image))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->PinHintBox))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
protected:
    virtual void WndProc(Message% m) override {
      Form::WndProc(m);

            if (m.Msg == 0x84 && (int)m.Result == 0x1)
                m.Result = (IntPtr)0x2;
    }

	 virtual void OnFormClosing(FormClosingEventArgs^ e ) override
        {
            Form::OnFormClosing(e);

            //if (e->CloseReason == CloseReason::WindowsShutDown) return;

            // Confirm user wants to close
			if (MessageBox::Show("Are you sure you want to close the application?", "Close Filement", MessageBoxButtons::YesNo, MessageBoxIcon::Question) == System::Windows::Forms::DialogResult::Yes)
			 {
				if (filement_thread && filement_thread->ThreadState == System::Threading::ThreadState::Running)
                    {
                        filement_thread->Abort();
                    }
                    filement_export_exit();
			}
			else
			{
				e->Cancel = true;
			}
            
        }

	private: System::Void Close_Click(System::Object^  sender, System::EventArgs^  e) {
				 Application::Exit();

				 
				/*
				this->Visible = false;
                this->ShowInTaskbar = false;
				this->WindowState= FormWindowState::Minimized;
				*/
				
			 }
 private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			  this->dname_box->Text = Environment::MachineName;
			  this->AboutVersion->Text = String::Concat(L"Version : ",gcnew System::String(filement_export_get_version()));
		 }
private: System::Void Link_Click(System::Object^  sender, System::EventArgs^  e) {
//			 	 ShellExecute (NULL,  L"open",  L"http://www.filement.com",  NULL,  NULL,  SW_SHOWNORMAL); 
		 }
private: System::Void hidePassword_Click(System::Object^  sender, System::EventArgs^  e) {
			 PasswordBox->UseSystemPasswordChar = true;
			 ShowPasswordBox->Visible=true;
			hidePassword->Visible=false;
		 }
private: System::Void ShowPasswordBox_Click(System::Object^  sender, System::EventArgs^  e) {
			 PasswordBox->UseSystemPasswordChar = false;
				ShowPasswordBox->Visible=false;
				hidePassword->Visible=true;
				//MessageBox::Show(Assembly::GetExecutingAssembly()->Location);

		 }
private: System::Void filementcomToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
	//		 ShellExecute (NULL,  L"open",  L"http://www.filement.com",  NULL,  NULL,  SW_SHOWNORMAL); 
		 }

private: System::Void PasswordBox_Enter(System::Object^  sender, System::EventArgs^  e) {
			  pass_descr_image->Visible = true;
		 }
private: System::Void PasswordBox_Leave(System::Object^  sender, System::EventArgs^  e) {
			  pass_descr_image->Visible = false;
		 }

private: System::Void email_box_Enter(System::Object^  sender, System::EventArgs^  e) {
			 PinHintBox->Visible = true;
		 }
private: System::Void email_box_Leave(System::Object^  sender, System::EventArgs^  e) {
			 PinHintBox->Visible = false;
		 }

private: System::Void PairButton_Click(System::Object^  sender, System::EventArgs^  e) {
		
       wchar_t *loc = GetAssemblyPath();
            if (filement_export_check_device(loc) == 1)
            {
                
                if (filement_thread && filement_thread->ThreadState != System::Threading::ThreadState::Running)
                {
                    filement_thread = gcnew Thread(gcnew ThreadStart(Server_Start));
					filement_thread->Name="Filement Server";
					filement_thread->Start();
               
					this->Visible = false;
					this->ShowInTaskbar = false;
					this->WindowState= FormWindowState::Minimized;
                }

            }
            else
            {
                if (email_box->Text->Length == 0)
                {
                    MessageBox::Show("The Email is empty.");
                    return;
                }
				else if (email_box->Text->Length > 200)
				{
					MessageBox::Show("The Email is too long.");
                    return;
				}
                if (dname_box->Text->Length == 0)
                {
                    MessageBox::Show("The Device Name is empty.");
                    return;
                }
				else if (dname_box->Text->Length > 200)
				{
					MessageBox::Show("The Device Name is too long.");
					return;
				}
                if (PasswordBox->Text->Length == 0)
                {
                    MessageBox::Show("The Device Password is empty. The Password is necessery for administrative tasks on your device.");
                    return;
                }


				pin_ptr<const wchar_t> email_box_conv=PtrToStringChars(email_box->Text);
				pin_ptr<const wchar_t> PasswordBox_conv=PtrToStringChars(PasswordBox->Text);
				pin_ptr<const wchar_t> dname_box_conv=PtrToStringChars(dname_box->Text);

                if (filement_export_register_device(loc, (wchar_t *)email_box_conv, 0, (wchar_t *)PasswordBox_conv, (wchar_t *)dname_box_conv) == 1)
                {

                   if (filement_thread && filement_thread->ThreadState != System::Threading::ThreadState::Running)
				  {
                    filement_thread = gcnew Thread(gcnew ThreadStart(Server_Start));
					filement_thread->Name="Filement Server";
					filement_thread->Start();
               
				
					}

                    RegisterInStartup(true);
                    MessageBox::Show("Your device is registered successfully. You can login in Filement.com to proceed.");

           			this->Visible = false;
					this->ShowInTaskbar = false;
					this->WindowState= FormWindowState::Minimized;
                }
                else
                {
                    MessageBox::Show("Problems with the registration.");
                }
            
            }

		 }


private: System::Void ctx_stop_server_Click(System::Object^  sender, System::EventArgs^  e) {
			 Application::Exit();
		 }
private: System::Void ctx_add_new_device_Click(System::Object^  sender, System::EventArgs^  e) {
			 if (MessageBox::Show(
     "Are you sure? If you click \"Yes\" the settings will be removed.", "Reinit Filement", MessageBoxButtons::YesNo, MessageBoxIcon::Question) == System::Windows::Forms::DialogResult::Yes)
			 {

                    if (filement_thread && filement_thread->ThreadState == System::Threading::ThreadState::Running)
                    {
                        filement_thread->Abort();
                    }
                      
                    wchar_t *loc = GetAssemblyPath();

                    filement_export_exec_reinit(loc);

                    
					this->Visible = true;
					this->ShowInTaskbar = true;
					this->WindowState= FormWindowState::Normal;
                    
			 
            }
		 }
};
}

